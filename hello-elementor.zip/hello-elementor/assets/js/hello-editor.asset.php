<?php return array('dependencies' => array(), 'version' => 'e289788a50eecad5c287');
