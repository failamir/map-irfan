<?php return array('dependencies' => array(), 'version' => 'ce55f4e617b3eb2a4c17');
